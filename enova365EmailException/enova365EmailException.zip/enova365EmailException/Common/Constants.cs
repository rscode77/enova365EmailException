﻿namespace enova365EmailException.Common
{
    internal static class Constants
    {
        public const string ReceipientEmailNode = "ReceipientEmailString";
        public const string SelectedEmailNode = "SelectedEmailString";
        public const string MainNode = "Soneta.EmailException";
        public const string SubNode = "EmailException";
        public const string ExtensionName = "enova365EmailException";
    }
}
